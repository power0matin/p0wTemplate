const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.svg': 'image/svg+xml'
};

// Mock data to simulate 3x-ui backend
const mockData = {
  "subTitle": "NeoTemplate Official",
  "email": "birthright_premium",
  "uploadByte": "1503238553",
  "downloadByte": "8589934592",
  "totalByte": "53687091200",
  "expire": Math.floor(Date.now() / 1000) + (14 * 24 * 60 * 60), // 14 days from now
  "upload": "1.4 GB",
  "download": "8.0 GB",
  "total": "50.0 GB",
  "used": "9.4 GB",
  "remained": "40.6 GB",
  "enabled": true,
  "subUrl": "https://example.com/sub/demo123",
  "proxies": [
    { "Name": "VLESS-TCP-Reality-US", "Link": "vless://12345678-1234-1234-1234-1234567890ab@example.com:443?type=tcp&security=reality#VLESS-TCP-Reality-US" },
    { "Name": "VMess-WS-TLS-UK", "Link": "vmess://eyJhZGQiOiJleGFtcGxlLmNvbSIsInBvcnQiOiI0NDMiLCJpZCI6IjEyMzQ1Njc4LTEyMzQtMTIzNC0xMjM0LTEyMzQ1Njc4OTBhYiJ9" }
  ]
};

const server = http.createServer((req, res) => {
  let filePath = path.join(__dirname, '..', req.url.split('?')[0]);
  
  if (req.url === '/' || req.url === '/preview/') {
    filePath = path.join(__dirname, '..', 'index.html');
  }

  const extname = path.extname(filePath);
  const contentType = MIME_TYPES[extname] || 'text/plain';

  fs.readFile(filePath, 'utf8', (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404);
        res.end('File not found: ' + req.url);
      } else {
        res.writeHead(500);
        res.end('Server error: ' + err.code);
      }
    } else {
      res.writeHead(200, { 
        'Content-Type': contentType,
        'Cache-Control': 'no-store'
      });
      
      // If it's an HTML file, inject mock data
      if (contentType === 'text/html') {
          let processed = content;
          // Simple replace for Go templates e.g. {{ .subTitle }}
          // Also handle {{ if .enabled }}Active{{ else }}Disabled{{ end }}
          processed = processed.replace(/{{s*.?([a-zA-Z0-9_]+)s*}}/g, (match, p1) => {
              // Ignore Name and Link as they are handled in the range loop
              if (p1 === 'Name' || p1 === 'Link') return match;
              return mockData[p1] !== undefined ? mockData[p1] : match;
          });
          
          // Handle simple if/else for enabled
          processed = processed.replace(/{{s*ifs*.enableds*}}(.*?){{s*elses*}}(.*?){{s*ends*}}/gs, (match, p1, p2) => {
              return mockData.enabled ? p1 : p2;
          });
          
          // Handle range .proxies
          processed = processed.replace(/{{s*ranges*.proxiess*}}(.*?){{s*ends*}}/gs, (match, content) => {
              let result = '';
              mockData.proxies.forEach(proxy => {
                  let item = content;
                  item = item.replace(/{{s*.Names*}}/g, proxy.Name);
                  item = item.replace(/{{s*.Links*}}/g, proxy.Link);
                  result += item;
              });
              return result;
          });
          
          res.end(processed, 'utf-8');
      } else {
          // Serve static files as buffers for images etc.
          fs.readFile(filePath, (err, rawContent) => {
             res.end(rawContent);
          });
      }
    }
  });
});

server.listen(0, '127.0.0.1', () => {
  const port = server.address().port;
  console.log(`NeoTemplate Local Server running at http://127.0.0.1:${port}/preview/index.html`);
  console.log('Press Ctrl+C to stop.');
  
  const url = `http://127.0.0.1:${port}/preview/index.html`;
  if (process.platform === 'win32') {
    exec(`start ${url}`);
  } else if (process.platform === 'darwin') {
    exec(`open ${url}`);
  } else {
    exec(`xdg-open ${url}`);
  }
});
